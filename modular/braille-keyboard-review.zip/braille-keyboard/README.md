# Compact Braille keyboard review

Editable Ergogen design and routed KiCad review files for a twelve-key wireless keyboard. The top and bottom rows have portrait 1.5U key envelopes; the middle row has 1U envelopes. The nice!nano, nice!view and battery are underneath, with the display between the controller and battery.

## Open these files

- `docs/switch-rotation-flow.svg`: source edit and commands to propagate a switch rotation through routing, previews, checks and web publication.
- `kicad/braille_review_routed.kicad_pcb`: the main PCB for manual placement and routing changes.
- `kicad/braille_assembly_preview.kicad_pcb`: the same PCB with the assembly envelope model attached for KiCad's 3D viewer.
- `previews/assembly-top.png` and `previews/assembly-bottom.png`: complete assembly views.
- `previews/modules-bottom.png`: underside components with the acrylic hidden.
- `previews/layout-review.svg`: dimensioned layout, underside, baseplate and height study.
- `output/outlines/baseplate.dxf`: acrylic outline and matching mounting holes.
- `ergogen/config.yaml`: editable layout, component placement and mechanical parameters.
- `kicad/pin-map.csv`, `kicad/drc-routed.txt` and `kicad/review-summary.json`: wiring, outstanding checks and measured dimensions.
- `models/routed-board.step`: board-only STEP geometry. The component and assembly models are separate VRML envelopes.

Keep the directory structure when opening the preview PCB: its model paths are relative to the `models` folder.

## Current draft dimensions

| Part | Dimensions |
| --- | --- |
| PCB | 75.2 × 75.2 × 1.6 mm |
| Acrylic baseplate | 75.2 × 75.2 mm; 3 mm thickness is provisional |
| Planar assembly, including USB and reset/power actuators | 76.0 × 77.469 mm, measured from the library geometry |
| Illustrated assembly height, including the ring | 20.0 mm, provisional |

The spacing reference transcribed as “subtle v1.1” remains unidentified. The draft uses configurable 19.05 mm units and nominal keycap envelopes, rather than verified dimensions from a purchased keycap set. The illustrated height assumes 6.5 mm standoffs, socket heights and keycap/switch envelopes that still need physical confirmation. The passive adhesive ring is provisionally 56 mm outside diameter, 46 mm inside diameter and 0.4 mm thick, beneath the acrylic. Flush underside fastener heads are assumed.

## Electrical design and remaining review

Each key has an independent controller input and a ground connection, allowing simultaneous Braille chords without a diode matrix. The underside controller socket has two thirteen-contact rows, including the extra B− and B+ terminals. The provisional JST-PH battery connector feeds the battery-disconnect switch, then switched VBAT at the controller; battery negative returns to ground. The side reset connects RST to ground. The USB envelope is outside the main PCB edge.

Real copper routing is imported from Freerouting. One display MOSI connection remains unrouted, between MCU1 pad 20 and DISP1 pad 5, at the accepted controller/switch interference. The accepted header/switch-hole clashes are marked on `User.1`. The DRC report also records the nearby copper clearance issue, the two added battery contacts' 0.42 mm edge clearance against the default 0.5 mm rule, solder-mask and silkscreen findings. Missing external `ceoloide` library warnings do not remove the footprints embedded in the PCB.

This is a review draft for the requested manual KiCad correction, not a fabrication release. The power-switch mounting tabs were moved fully onto the PCB and reset was inset for edge clearance. The accepted controller clashes and key spacing were preserved. All 3D component solids are labelled dimension envelopes, not manufacturer models. Ring/fastener clearance in the preview depends on the provisional ring and flush screw heads.

An electrical schematic, ZMK firmware and an inter-module connection scheme are not included; those requirements have not been specified.

## Rebuild

Use Node.js/npm, Python with KiCad 9's `pcbnew` module, and `kicad-cli`. Mesh generation also needs the versions in `requirements-preview.txt`, installed in your Python environment or under `tools/pydeps`.

```sh
npm ci
npm run build
python3 scripts/prepare_kicad.py
python3 scripts/route_board.py --jar /path/to/freerouting-2.2.4.jar --java /path/to/java25
python3 scripts/render_review.py
npm run check
```

Routing uses Freerouting 2.2.4 and Java 25 or newer. The download bundle excludes installed dependencies, the Java runtime and the router binary. Rebuilding replaces generated outputs, so save manual KiCad changes separately first.

## References and notices

- [Ergogen documentation](https://docs.ergogen.xyz/)
- [nice!nano pinout and schematic](https://nicekeyboards.com/docs/nice-nano/pinout-schematic/)
- [nice!view dimensions and specifications](https://nicekeyboards.com/nice-view/)
- [Ceoloide Ergogen footprints](https://github.com/ceoloide/ergogen-footprints)
- [Freerouting](https://github.com/freerouting/freerouting)

Upstream provenance is recorded in `ergogen/footprints/ceoloide/upstream.json`. Original per-file notices are preserved, including CC-BY-NC-SA-4.0 notices in the controller and display footprints; the repository's top-level MIT file does not replace those notices. The local controller adapter adds the battery-header row without discarding the upstream implementation.
